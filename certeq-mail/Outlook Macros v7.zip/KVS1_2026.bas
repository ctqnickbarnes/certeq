Attribute VB_Name = "KVS1_2026"
Sub API_Logon()
API_Login.Show
End Sub
Sub Menu_load()
Certeq_Menu_KVS1.Show
End Sub
Sub SOE_AU_Recovery()
   'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/220?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
       
            If ExportArray(rw, col) = "Store" Then
            col = col + 1
                Store_ID = ExportArray(rw, col)
            Else: End If

            If ExportArray(rw, col) = "Store Name" Then
            col = col + 1
                Store_Name = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "IP" Then
            col = col + 1
                Store_IP = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "State" Then
            col = col + 1
                Store_State = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Status" Then
            col = col + 1
                Store_Status = ExportArray(rw, col)
            Else: End If
            
       Next col
    Next rw

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    ' Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    ' Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)


    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Level 2,"
    
    EmailBody = EmailBody & "<br><br>We have just installed a VM SOE at <b>" & Store_ID & " - " & Store_Name & "</b>, could you please kick off the SOE recovery file distribution job with the following details:"
        
        EmailBody = EmailBody & "<br><br><ul><table><font face=""Calibri"" font size=""2"" color=""black""><tr>"
        EmailBody = EmailBody & "<td>Market:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">AU</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site ID:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_ID & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site Name:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_Name & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>SOE IP:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_IP & ".1</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>State</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_State & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Status</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_Status & "</td>"
        EmailBody = EmailBody & "</tr></table></ul>"
    
    EmailBody = EmailBody & SignatureContent
                
    With OutMail
        .To = "IT.RestaurantSupport@au.mcd.com"
        .CC = "mcd@certeq.com.au;karthick.raghuraman@au.mcd.com;Malcolm.Little@au.mcd.com;jason.conevski@au.mcd.com"
        .BCC = ""
        .Subject = "SOE VM Recovery: " & Store_ID & " - " & Store_Name
        .HTMLBody = EmailBody
        .Display
    End With


End Sub


    
Sub DMAAS_AU()
    'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/1320?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
       
            If ExportArray(rw, col) = "Store" Then
            col = col + 1
                Store_ID = ExportArray(rw, col)
            Else: End If

            If ExportArray(rw, col) = "Store Name" Then
            col = col + 1
                Store_Name = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Owner" Then
            col = col + 1
                Owner = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Network_LanAddress" Then
            col = col + 1
                Network_LanAddress = ExportArray(rw, col)
            Else: End If
            
             If ExportArray(rw, col) = "RHS01 MAC" Then
            col = col + 1
                RHS01 = ExportArray(rw, col)
            Else: End If
            
             If ExportArray(rw, col) = "RHS02 MAC" Then
            col = col + 1
                RHS02 = ExportArray(rw, col)
            Else: End If
            
            
             If ExportArray(rw, col) = "State" Then
            col = col + 1
                State = ExportArray(rw, col)
            Else: End If
            
       Next col
    Next rw

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "<b>Service Caf� Ticket Mapping (Country code in format AU or NZ)</b>"
    EmailBody = EmailBody & "<br>" & "Site ID: " & Store_ID
    EmailBody = EmailBody & "<br>" & "Country Code: AU"
    
    EmailBody = EmailBody & "<br><br>" & "<b>The following store has been staged:</b>"
    EmailBody = EmailBody & "<br>" & "McD " & Store_ID & " " & Store_Name & " " & State & " Australia"
    
    EmailBody = EmailBody & "<br><br>" & "<b>ACTION REQUIRED:</b> DMaaS L3 / RSM L3 / McD Level 2 - This request has been created for your action. Ensure you have completed your relevant tasks below before closing this request!"
    
    EmailBody = EmailBody & "<br><br>" & "<b><u>IP Addresses</b></u><ul>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "SOE01 - " & Network_LanAddress & ".1</li>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "GSC01 - " & Network_LanAddress & ".124</li>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "GSC02 - " & Network_LanAddress & ".123</li>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "RHS01 - " & Network_LanAddress & ".94</li>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "RHS02 - " & Network_LanAddress & ".93</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>Remote Management Interface Details</b></u><ul>"

    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "RHS01 - " & RHS01 & "</li>"
    EmailBody = EmailBody & "<li>" & "AU0" & Store_ID & "RHS02 - " & RHS02 & "</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>DMaaS L3 GLOBAL Support Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Provision restaurant in DMaaS</li>"
    EmailBody = EmailBody & "<li>Test DMaaS connectivity from the DMaaS Servers to the Waystation DMaaS client</li>"
    EmailBody = EmailBody & "<li>Once validated, please advise the McDonald's RFM Team so they can test RFM package delivery </li>"

    EmailBody = EmailBody & "</ul>" & "<b><u>McD IT Foundation Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Check all switch interconnections are working as required</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>McD L2 Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Ensure the correct groups are applied to the SOE in Resilio. (State group for the restaurant's location should be added as a minimum)</li>"
    EmailBody = EmailBody & "<li>Update " & Chr(34) & "Restaurant Connectivity Configurator" & Chr(34) & " to update RDCMan (*.rdg) file with Waystation and Production Host Names (GSC01/GSC02)</li>"
    EmailBody = EmailBody & "<li>Run Apps to SOE Recovery Job (1 hour process)</li>"
    EmailBody = EmailBody & "<li>Validate POSConnector is running on Waystation after Apps to SOE Recovery Job</li>"
    EmailBody = EmailBody & "<li>Escalate to MFM/RFM for completion of their tasks</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>RFM Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Please Update/Confirm RFM to ensure KS Groups align with KVS1 requirements</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>KVS</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>POS</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>ORB</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Hub and Spoke: Yes</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>Capgemini Service Desk:</b></u><ul>"
    EmailBody = EmailBody & "<li>This store is on NextGen Back-Office Platform, Test RDP & UltraVNC connectivity to the Back-Office SOE PC and relevant devices</li>"
    EmailBody = EmailBody & "<li>Communicate this restaurant is now on KVS1</li>"
    
    EmailBody = EmailBody & "</ul><font face=""Calibri"" font size=""4"" color=""black""><b>This store's Go Live date is:  " & Format(Now(), "DDD, DD-MMM-YY")
    
    EmailBody = EmailBody & "</b><br><br><font face=""Calibri"" font size=""2"" color=""black"">"
    With OutMail
        .To = "servicecafe@service-now.com;cfm@au.mcd.com;anzsupportleads1.5.in@capgemini.com;aus-it-networkteam@au.mcd.com;US-DL_DMaaS_Operations@us.mcd.com;US-DL_RTPaaS_RSM_L3_Service@us.mcd.com"
        .CC = "mcd@certeq.com.au;Malcolm.Little@au.mcd.com;McD_IT_Deploy@au.mcd.com;aurtpteam@au.mcd.com;Troy.Urquhart@certeq.com.au;daniel.phillips@certeq.com.au;nic.henstridge@certeq.com.au;dave.hawtin@certeq.com.au"
        .BCC = ""
        .Subject = "DMaaS / RSM / McD - " & Store_ID & " " & Store_Name & " " & State & " " & Owner & " (Australia)"
        .HTMLBody = EmailBody
        .Display
    End With


End Sub
Sub SOE_NZ_Recovery()
   'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3613?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
       
            If ExportArray(rw, col) = "Store" Then
            col = col + 1
                Store_ID = ExportArray(rw, col)
            Else: End If

            If ExportArray(rw, col) = "Store Name" Then
            col = col + 1
                Store_Name = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "IP" Then
            col = col + 1
                Store_IP = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "State" Then
            col = col + 1
                Store_State = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Status" Then
            col = col + 1
                Store_Status = ExportArray(rw, col)
            Else: End If
            
       Next col
    Next rw

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    ' Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    ' Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)


    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Level 2,"
    
    EmailBody = EmailBody & "<br><br>We have just installed a VM SOE at <b>" & Store_ID & " - " & Store_Name & "</b>, could you please kick off the SOE recovery file distribution job with the following details:"
        
        EmailBody = EmailBody & "<br><br><ul><table><font face=""Calibri"" font size=""2"" color=""black""><tr>"
        EmailBody = EmailBody & "<td>Market:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">NZ</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site ID:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_ID & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site Name:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_Name & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>SOE IP:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_IP & ".1</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>State</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_State & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Status</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_Status & "</td>"
        EmailBody = EmailBody & "</tr></table></ul><br>"
    
    EmailBody = EmailBody & SignatureContent
                
    With OutMail
        .To = "IT.RestaurantSupport@au.mcd.com"
        .CC = "sme@certeq.com.au;caleb.archer@nz.mcd.com"
        .BCC = ""
        .Subject = "SOE VM Recovery: " & Store_ID & " - " & Store_Name
        .HTMLBody = EmailBody
        .Display
    End With


End Sub

Sub KVS1_NZ_Completion()
    'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3612?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing

    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    
    'Determin Array Size
    y = 500
    x = 2
    
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
    
    PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                
                Case ":":
                    Endlabel = PosStr - 1
                    Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                    ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                    ValTxt = 0
                    StartValue = PosStr + 1
                    
                Case ",":
                    If ValTxt = 1 Then
                        EndValue = PosStr - 1
                        ValTxt = 0
                    Else
                        EndValue = PosStr
                    End If
                    
                    Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                    ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                    ArrayY = ArrayY + 1
                    StartValue = PosStr
                    
                Case "}":
                    EndValue = PosStr
                    Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                    ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                    ArrayY = ArrayY + 1
                    StartValue = PosStr + 1
                    
                Case Else:
            End Select
        Else
            Select Case PosChr
                Case "\"
                    PosStr = PosStr + 1 ' Skip the next character
                    
                Case Else:
            End Select
        End If
        
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
        For col = 0 To x
       
            If ExportArray(rw, col) = "Ref_ID" Then
                col = col + 1
                Ref_ID = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "Site_ID" Then
                col = col + 1
                Site_ID = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "Site_Name" Then
                col = col + 1
                Site_Name = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "whatsapp_hypersupport" Then
                col = col + 1
                whatsapp_hypersupport = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "whatsapp_qr" Then
                col = col + 1
                whatsapp_qr = ExportArray(rw, col)
            Else:
            End If
              
            If ExportArray(rw, col) = "support_date" Then
                col = col + 1
                support_date = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_dl" Then
                col = col + 1
                email_dl = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_cc" Then
                col = col + 1
                email_cc = ExportArray(rw, col)
            Else:
            End If
            
        Next col
    Next rw

    ' Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    ' Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    
    Dim EmailBody As String
    
    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Restaurant Manager,"

    EmailBody = EmailBody & "<br><br>Certeq has now completed the <b>KVS1 Conversion</b> at your <b>" & Site_Name & "</b> restaurant."

    EmailBody = EmailBody & "<br><br>We will be running our Hyper Support through WhatsApp until <b>" & support_date & "</b>. If you could please ensure your team raises any faults by replying to this email or via the WhatsApp Chat:"
    'QR Code
    EmailBody = EmailBody & "<br><br>QR Code:"
    whatsapp_qr = "https://api.qrserver.com/v1/create-qr-code/?data=" & whatsapp_hypersupport & "&size=150x150"
    EmailBody = EmailBody & "<br><img src=""" & whatsapp_qr & """>"
    EmailBody = EmailBody & "<br><br><i>Note: You may need to click the email popup 'Click here to download pictures. To help protect your privacy, Outlook prevented automatic download of some pictures in this message.' to display the QR Code.</i>"
    EmailBody = EmailBody & "<br><br>URL:"
    EmailBody = EmailBody & "<br><a href=""" & whatsapp_hypersupport & """ target=""_blank"">" & whatsapp_hypersupport & "</a></ul>"

    EmailBody = EmailBody & "<br><b>Maxtel Sales Data:</b>"
    EmailBody = EmailBody & "<ul><br>Please note that because of the change to the Virtual SOE Maxtel is required to manually log on and install OnTarget."
    EmailBody = EmailBody & "<br><br>Sales data will start flowing through to Maxtel Web after a few hours."
    EmailBody = EmailBody & "<br><br>If it reaches midday and you are still having issues with sales data to either Maxtel Web or OnTarget please reach out to Certeq via the Hyper-Support Chat.</ul>"
    
    EmailBody = EmailBody & "<br>If you have any urgent issues that are impacting trade please contact our After Hours Support via:"
    EmailBody = EmailBody & "<br><br><ul>Certeq Project Team"
    EmailBody = EmailBody & "<br><a href=""mailto:mcd@certeq.co.nz"">mcd@certeq.co.nz</a>"
    EmailBody = EmailBody & "<br>Phone: <a href=""tel:+61448003441"">+61 448 003 441</a></ul>"

    EmailBody = EmailBody & "<br><br>If you would like to provide us with some feedback on this installation, this can be completed via: <a href=""https://feedback.certeq.com.au"">feedback.certeq.com.au</a>"

    EmailBody = EmailBody & "<br><br>"
    EmailBody = EmailBody & SignatureContent

    With OutMail
        .To = email_dl
        .CC = email_cc
        .BCC = ""
        .Subject = "[Post Deployment Support] Ref ID: " & Ref_ID & " | KVS1 Conversion: " & Site_ID & " - " & Site_Name
        .HTMLBody = EmailBody
        .Display
    End With
End Sub


    
    
Sub DMAAS_NZ()
    'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3609?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
       
            If ExportArray(rw, col) = "Store" Then
            col = col + 1
                Store_ID = ExportArray(rw, col)
            Else: End If

            If ExportArray(rw, col) = "Store Name" Then
            col = col + 1
                Store_Name = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Owner" Then
            col = col + 1
                Owner = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Network_LanAddress" Then
            col = col + 1
                Network_LanAddress = ExportArray(rw, col)
            Else: End If
            
             If ExportArray(rw, col) = "RHS01 MAC" Then
            col = col + 1
                RHS01 = ExportArray(rw, col)
            Else: End If
            
             If ExportArray(rw, col) = "RHS02 MAC" Then
            col = col + 1
                RHS02 = ExportArray(rw, col)
            Else: End If
            
            
             If ExportArray(rw, col) = "State" Then
            col = col + 1
                State = ExportArray(rw, col)
            Else: End If
            
       Next col
    Next rw

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "<b>Service Caf� Ticket Mapping (Country code in format AU or NZ)</b>"
    EmailBody = EmailBody & "<br>" & "Site ID: " & Store_ID
    EmailBody = EmailBody & "<br>" & "Country Code: NZ"
    
    EmailBody = EmailBody & "<br><br>" & "<b>The following store has been staged:</b>"
    EmailBody = EmailBody & "<br>" & "McD " & Store_ID & " " & Store_Name & " " & State & " New Zealand"
    
    EmailBody = EmailBody & "<br><br>" & "<b>ACTION REQUIRED:</b> DMaaS L3 / RSM L3 / McD Level 2 - This request has been created for your action. Ensure you have completed your relevant tasks below before closing this request!"
    
    EmailBody = EmailBody & "<br><br>" & "<b><u>IP Addresses</b></u><ul>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "SOE01 - " & Network_LanAddress & ".1</li>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "GSC01 - " & Network_LanAddress & ".124</li>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "GSC02 - " & Network_LanAddress & ".123</li>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "RHS01 - " & Network_LanAddress & ".94</li>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "RHS02 - " & Network_LanAddress & ".93</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>Remote Management Interface Details</b></u><ul>"

    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "RHS01 - " & RHS01 & "</li>"
    EmailBody = EmailBody & "<li>" & "NZ0" & Store_ID & "RHS02 - " & RHS02 & "</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>DMaaS L3 GLOBAL Support Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Provision restaurant in DMaaS</li>"
    EmailBody = EmailBody & "<li>Test DMaaS connectivity from the DMaaS Servers to the Waystation DMaaS client</li>"
    EmailBody = EmailBody & "<li>Once validated, please advise the McDonald's RFM Team so they can test RFM package delivery </li>"

    EmailBody = EmailBody & "</ul>" & "<b><u>McD IT Foundation Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Check all switch interconnections are working as required</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>McD L2 Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Ensure the correct groups are applied to the SOE in Resilio. (State group for the restaurant's location should be added as a minimum)</li>"
    EmailBody = EmailBody & "<li>Update " & Chr(34) & "Restaurant Connectivity Configurator" & Chr(34) & " to update RDCMan (*.rdg) file with Waystation and Production Host Names (GSC01/GSC02)</li>"
    EmailBody = EmailBody & "<li>Run Apps to SOE Recovery Job (1 hour process)</li>"
    EmailBody = EmailBody & "<li>Validate POSConnector is running on Waystation after Apps to SOE Recovery Job</li>"
    EmailBody = EmailBody & "<li>Escalate to MFM/RFM for completion of their tasks</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>RFM Team:</b></u><ul>"
    EmailBody = EmailBody & "<li>Please Update/Confirm RFM to ensure KS Groups align with KVS1 requirements</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>KVS</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>POS</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Delivery <u>ORB</u>: Yes</li>"
    EmailBody = EmailBody & "<li>The restaurant has a Hub and Spoke: Yes</li>"
    
    EmailBody = EmailBody & "</ul>" & "<b><u>Capgemini Service Desk:</b></u><ul>"
    EmailBody = EmailBody & "<li>This store is on NextGen Back-Office Platform, Test RDP & UltraVNC connectivity to the Back-Office SOE PC and relevant devices</li>"
    EmailBody = EmailBody & "<li>Communicate this restaurant is now on KVS1</li>"
    
    EmailBody = EmailBody & "</ul><font face=""Calibri"" font size=""4"" color=""black""><b>This store's Go Live date is:  " & Format(Now(), "DDD, DD-MMM-YY")
    
    EmailBody = EmailBody & "</b><br><br><font face=""Calibri"" font size=""2"" color=""black"">"
    With OutMail
        .To = "servicecafe@service-now.com;cfm@au.mcd.com;anzsupportleads1.5.in@capgemini.com;aus-it-networkteam@au.mcd.com;US-DL_DMaaS_Operations@us.mcd.com;US-DL_RTPaaS_RSM_L3_Service@us.mcd.com"
        .CC = "sme@certeq.com.au;McD_IT_Deploy@au.mcd.com;aurtpteam@au.mcd.com;caleb.archer@nz.mcd.com"
        .BCC = ""
        .Subject = "DMaaS / RSM / McD - " & Store_ID & " " & Store_Name & " " & State & " " & Owner & " (New Zealand)"
        .HTMLBody = EmailBody
        .Display
    End With


End Sub

Sub Maxtel_Recovery()
   'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3613?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
       
            If ExportArray(rw, col) = "Store" Then
            col = col + 1
                Store_ID = ExportArray(rw, col)
            Else: End If

            If ExportArray(rw, col) = "Store Name" Then
            col = col + 1
                Store_Name = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "IP" Then
            col = col + 1
                Store_IP = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "State" Then
            col = col + 1
                Store_State = ExportArray(rw, col)
            Else: End If
            
            If ExportArray(rw, col) = "Status" Then
            col = col + 1
                Store_Status = ExportArray(rw, col)
            Else: End If
            
       Next col
    Next rw

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    ' Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    ' Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)


    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Maxtel Team,"
    
    EmailBody = EmailBody & "<br><br>We have just installed a VM SOE at <b>" & Store_ID & " - " & Store_Name & "</b>."
    EmailBody = EmailBody & "<br><br>Can you please confirm that you are receiving all appropriate files post this upgrade."
    EmailBody = EmailBody & "<br><br>The VM SOE has been configured with the following details:"
        EmailBody = EmailBody & "<br><br><ul><table><font face=""Calibri"" font size=""2"" color=""black""><tr>"
        EmailBody = EmailBody & "<td>Market:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">NZ</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site ID:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_ID & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>Site Name:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_Name & "</td>"
        EmailBody = EmailBody & "</tr><tr>"
        EmailBody = EmailBody & "<td>SOE IP:</td>"
        EmailBody = EmailBody & "<td style=""padding-left:10px;"">" & Store_IP & ".1</td>"
        EmailBody = EmailBody & "</tr></table></ul><br>"
    
    EmailBody = EmailBody & SignatureContent
                
    With OutMail
        .To = "support@maxtel.com"
        .CC = "sme@certeq.com.au;caleb.archer@nz.mcd.com;steven.fox@maxtel.com;james.diamond-jennings@maxtel.com"
        .BCC = ""
        .Subject = "NZ" & Store_ID & " -" & Store_Name & " | VM SOE Upgrade | Maxtel Checks"
        .HTMLBody = EmailBody
        .Display
    End With


End Sub

Sub KVS1NZ_Daily_Report()

    Dim http As Object
    Dim jsonStr As String
    Dim HTMLTable As String
    Dim Pos As Long
    
    Dim ID As String
    Dim SiteName As String
    Dim InstallDate As String
    Dim Status As String
    Dim Authority As String
    
    Set http = CreateObject("MSXML2.ServerXMLHTTP")

    With http
        .Open "GET", "https://api.certeq.com.au/custom-reports/queries/3614", False
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .setRequestHeader "Accept", "application/json"
        .Send
        
        jsonStr = .ResponseText
    End With
    
    Debug.Print jsonStr
    
    Set http = Nothing


    'Create HTML Table
    HTMLTable = "<table><font face=""Calibri"" font size=""2"" color=""black"">"

    'Header row
    HTMLTable = HTMLTable & "<tr>"
    HTMLTable = HTMLTable & "<th font size=""2"" style=""padding-left:10px;padding-right:10px"" align=""left"">ID</th>"
    HTMLTable = HTMLTable & "<th font size=""2"" style=""padding-left:10px;padding-right:10px"" align=""left"">Site Name</th>"
    HTMLTable = HTMLTable & "<th font size=""2"" style=""padding-left:10px;padding-right:10px"" align=""left"">Install Date</th>"
    HTMLTable = HTMLTable & "<th font size=""2"" style=""padding-left:10px;padding-right:10px"" align=""left"">Status</th>"
    HTMLTable = HTMLTable & "<th font size=""2"" style=""padding-left:10px;padding-right:10px"" align=""left"">Authority to Open given</th>"
    HTMLTable = HTMLTable & "</tr>"


    'Loop JSON rows
    Pos = 1

    Do

        ID = GetJSONValue(jsonStr, "ID", Pos)

        If ID = "" Then Exit Do

        SiteName = GetJSONValue(jsonStr, "Site Name", Pos)
        InstallDate = GetJSONValue(jsonStr, "Install Date", Pos)
        Status = GetJSONValue(jsonStr, "Status", Pos)
        Authority = GetJSONValue(jsonStr, "Authority to Open given", Pos)


        'Add table row
        HTMLTable = HTMLTable & "<tr>"

        HTMLTable = HTMLTable & "<td font size=""2"" style=""border-color:#5b9bd5;border-left-style:solid;border-width:1px;padding-left:10px;padding-right:10px""> " & ID & " </td>"
        
        HTMLTable = HTMLTable & "<td font size=""2"" style=""border-color:#5b9bd5;border-left-style:solid;border-width:1px;padding-left:10px;padding-right:10px""> " & SiteName & " </td>"
        
        HTMLTable = HTMLTable & "<td font size=""2"" style=""border-color:#5b9bd5;border-left-style:solid;border-width:1px;padding-left:10px;padding-right:10px""> " & InstallDate & " </td>"
        
        HTMLTable = HTMLTable & "<td font size=""2"" style=""border-color:#5b9bd5;border-left-style:solid;border-width:1px;padding-left:10px;padding-right:10px""> " & Status & " </td>"
        
        HTMLTable = HTMLTable & "<td font size=""2"" style=""border-color:#5b9bd5;border-left-style:solid;border-width:1px;padding-left:10px;padding-right:10px""> " & Authority & " </td>"

        HTMLTable = HTMLTable & "</tr>"


        Pos = InStr(Pos, jsonStr, "}") + 1

    Loop


    HTMLTable = HTMLTable & "</table>"


    'Create Outlook Email
    Dim OutApp As Object
    Dim OutMail As Object
    Dim EmailBody As String
    
    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)


    'Load Outlook Signature
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso
    
    Set fso = CreateObject("Scripting.FileSystemObject")
    
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    
    Dim SignatureBaseURL
    
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)


    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Team,"
    
    EmailBody = EmailBody & "<br><br>Please see the report for last nights KVS1 conversions:"
    EmailBody = EmailBody & "<br><br><ul>"
    EmailBody = EmailBody & HTMLTable
    
    EmailBody = EmailBody & "</ul><br><br><b>Conversion Notable Items:</b>"
    EmailBody = EmailBody & "<br><br><b>Lessons Learnt:</b><br><br>"
    
    EmailBody = EmailBody & SignatureContent


    With OutMail
    
        .To = "caleb.archer@nz.mcd.com;david.moors@nz.mcd.com;brook.dando@nz.mcd.com;jonathan.wong@nz.mcd.com"
        .CC = "sme@certeq.com.au;mcd@certeq.co.nz;sme@certeq.com.au;aus-it-networkteam@au.mcd.com;it.restaurantsupport@au.mcd.com;aurtpteam@mcdonaldscorp.onmicrosoft.com"
        .BCC = ""
        .Subject = "KVS1 Conversions Report (NZ & PI): " & Format(Date, "dddd, dd-mmm-yy")
        .HTMLBody = EmailBody
        .Display
        
    End With


End Sub

Function GetJSONValue(json As String, FieldName As String, StartPos As Long) As String

    Dim FieldPos As Long
    Dim ValueStart As Long
    Dim ValueEnd As Long

    FieldPos = InStr(StartPos, json, """" & FieldName & """")

    If FieldPos = 0 Then Exit Function

    ValueStart = InStr(FieldPos, json, ":") + 1

    Do While Mid(json, ValueStart, 1) = " "
        ValueStart = ValueStart + 1
    Loop


    If Mid(json, ValueStart, 1) = """" Then
        
        ValueStart = ValueStart + 1
        ValueEnd = InStr(ValueStart, json, """")

    Else
        
        ValueEnd = InStr(ValueStart, json, ",")
        
        If ValueEnd = 0 Then
            ValueEnd = InStr(ValueStart, json, "}")
        End If
        
    End If


    GetJSONValue = Trim(Mid(json, ValueStart, ValueEnd - ValueStart))

End Function

Sub KVS_NZ_Completion_Issues_Update()
    'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3612?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    
   End With
   
    'Display Results
    Debug.Print jsonStr
    Set objRequest = Nothing


    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           Debug.Print Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr
                            Debug.Print "  " & Mid(jsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
              Case "\"
                PosStr = PosStr + 1 ' Skip the next character
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
        For col = 0 To x
       
            If ExportArray(rw, col) = "Ref_ID" Then
                col = col + 1
                Ref_ID = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "Site_ID" Then
                col = col + 1
                Site_ID = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "Site_Name" Then
                col = col + 1
                Site_Name = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "whatsapp_hypersupport" Then
                col = col + 1
                whatsapp_hypersupport = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "whatsapp_qr" Then
                col = col + 1
                whatsapp_qr = ExportArray(rw, col)

            Else:
            End If
              
            If ExportArray(rw, col) = "support_date" Then
                col = col + 1
                support_date = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_dl" Then
                col = col + 1
                email_dl = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_cc" Then
                col = col + 1
                email_cc = ExportArray(rw, col)
            Else:
            End If
            
        Next col
    Next rw

    ' Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    ' Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)


    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    Dim EmailBody As String
    
    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

EmailBody = EmailBody & "Hi Restaurant Manager,"

EmailBody = EmailBody & "<br><br>An update on the issues from <b>KVS1 Conversion</b> at your <b>" & Site_Name & "</b> restaurant:"

    EmailBody = EmailBody & "<ul><li><b>Issue Description</b> | Status: <b><font color=""red"">OPEN</font></b> (Certeq - to resolve)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">OPEN</font></b> (Resturant - to resolve)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Certeq L2)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (McD L2)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Maxtel)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Seaseme)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (RTP)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""green"">RESOLVED</font></b></li></ul>"

EmailBody = EmailBody & "If you are still seeing issues outside of the above list please reply to this email or respond to us via WhatsApp: <a href=""" & whatsapp_hypersupport & """ target=""_blank"">" & whatsapp_hypersupport & "</a>"

EmailBody = EmailBody & "<br><br>If you have any urgent issues that are impacting trade please contact our After Hours Support via:"

EmailBody = EmailBody & "<br><br><ul>Certeq Project Team"
EmailBody = EmailBody & "<br><a href=""mailto:mcd@certeq.com.au"">mcd@certeq.com.au</a>"
EmailBody = EmailBody & "<br>Phone: <a href=""tel:+61448003441"">+61 448 003 441</a></ul>"

EmailBody = EmailBody & "<br>If you would like to provide us with some feedback on this installation, this can be completed via: <a href=""https://feedback.certeq.com.au"">feedback.certeq.com.au</a>"

EmailBody = EmailBody & "<br><br>"
EmailBody = EmailBody & SignatureContent

    With OutMail
        .To = email_dl
        .CC = email_cc
        .BCC = ""
        .Subject = "[Post Deployment Support - Update] Ref ID: " & Ref_ID & " | KVS1 Conversion: " & Site_ID & " - " & Site_Name
        .HTMLBody = EmailBody
        .Display
    End With
End Sub


Sub KVS_NZ_Completion_Issues()
    'Set Array Variables
    Dim objRequest As Object
    Dim json As String
    Dim result As String
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    Site_ID = InputBox("Enter the Site ID for import", "Certeq API")
    URL = "https://api.certeq.com.au/custom-reports/queries/3612?Site_ID=" & Site_ID
    
    'Call API
    With objRequest
        .Open "GET", URL, False
        .setRequestHeader "Content-type", "application/json"
        .setRequestHeader "Accept", "application/json"
        .setRequestHeader "Authorization", "Bearer " & GetSetting("Certeq", "Portal_API", "Token")
        .Send
        jsonStr = .ResponseText
    End With
   
    'Display Results

    Set objRequest = Nothing

    Dim ExportArray() As Variant
    Dim x, y, row, col As Integer
    
    'Determin Array Size
    y = 500
    x = 2
    
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
    
    PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                
                Case ":":
                    Endlabel = PosStr - 1
                    
                    ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                    ValTxt = 0
                    StartValue = PosStr + 1
                    
                Case ",":
                    If ValTxt = 1 Then
                        EndValue = PosStr - 1
                        ValTxt = 0
                    Else
                        EndValue = PosStr
                    End If
                    

                    ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                    ArrayY = ArrayY + 1
                    StartValue = PosStr
                    
                Case "}":
                    EndValue = PosStr

                    ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                    ArrayY = ArrayY + 1
                    StartValue = PosStr + 1
                    
                Case Else:
            End Select
        Else
            Select Case PosChr
                Case "\"
                    PosStr = PosStr + 1 ' Skip the next character
                    
                Case Else:
            End Select
        End If
        
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
        For col = 0 To x
       
            If ExportArray(rw, col) = "Ref_ID" Then
                col = col + 1
                Ref_ID = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "Site_ID" Then
                col = col + 1
                Site_ID = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "Site_Name" Then
                col = col + 1
                Site_Name = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "whatsapp_hypersupport" Then
                col = col + 1
                whatsapp_hypersupport = ExportArray(rw, col)
            Else:
            End If

            If ExportArray(rw, col) = "whatsapp_qr" Then
                col = col + 1
                whatsapp_qr = ExportArray(rw, col)

            Else:
            End If
              
            If ExportArray(rw, col) = "support_date" Then
                col = col + 1
                support_date = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_dl" Then
                col = col + 1
                email_dl = ExportArray(rw, col)
            Else:
            End If
            
            If ExportArray(rw, col) = "email_cc" Then
                col = col + 1
                email_cc = ExportArray(rw, col)
            Else:
            End If
            
        Next col
    Next rw

    'Find and load the default signature HTML from the file
    Dim SignatureFolderPath
    SignatureFolderPath = Environ("APPDATA") & "\Microsoft\Signatures\"
    
    Dim SignatureContent
    Dim SignatureFile
    Dim fso: Set fso = CreateObject("Scripting.FileSystemObject")
    
    For Each SignatureFile In fso.GetFolder(SignatureFolderPath).Files
        If InStr(1, SignatureFile.Name, ".htm", vbTextCompare) > 0 Then
            SignatureContent = fso.OpenTextFile(SignatureFile.Path).ReadAll
            Exit For
        End If
    Next
    
    'Modify the image URLs to use absolute URLs based on the signature folder
    Dim SignatureBaseURL
    SignatureBaseURL = "file://" & Replace(SignatureFolderPath, "\", "/") & "/"
    SignatureContent = Replace(SignatureContent, "src=""", "src=""" & SignatureBaseURL)

    Set OutApp = CreateObject("Outlook.Application")
    Set OutMail = OutApp.CreateItem(0)
    
    Dim EmailBody As String
    
    EmailBody = "<font face=""Calibri"" font size=""2"" color=""black"">"

    EmailBody = EmailBody & "Hi Restaurant Manager,"

    EmailBody = EmailBody & "<br><br>Certeq has now completed the <b>KVS1 Conversion</b> at your <b>" & Site_Name & "</b> restaurant."

    EmailBody = EmailBody & "<br><br>During the conversion the following issues that arose that we still need to close out:"


    EmailBody = EmailBody & "<ul><li><b>Issue Description</b> | Status: <b><font color=""red"">OPEN</font></b> (Certeq - to resolve)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">OPEN</font></b> (Resturant - to resolve)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Certeq L2)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (McD L2)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Maxtel)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (Seaseme)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""red"">ESCALATED</font></b> (RTP)</li>"
    EmailBody = EmailBody & "<li><b>Issue Description</b> | Status: <b><font color=""green"">RESOLVED</font></b></li></ul>"


    EmailBody = EmailBody & "We will be running our Hyper Support through WhatsApp until <b>" & support_date & "</b>. If you could please ensure your team raises any faults by replying to this email or via the WhatsApp Chat:"
    
    EmailBody = EmailBody & "<br><br><ul>QR Code:"
    
    'QR Code
    whatsapp_qr = "https://api.qrserver.com/v1/create-qr-code/?data=" & whatsapp_hypersupport & "&size=150x150"
    EmailBody = EmailBody & "<br><img src=""" & whatsapp_qr & """>"

    EmailBody = EmailBody & "<br><br><i>Note: You may need to click the email popup 'Click here to download pictures. To help protect your privacy, Outlook prevented automatic download of some pictures in this message.' to display the QR Code.</i>"
    EmailBody = EmailBody & "<br><br>URL:"
    EmailBody = EmailBody & "<br><a href=""" & whatsapp_hypersupport & """ target=""_blank"">" & whatsapp_hypersupport & "</a></ul>"

    EmailBody = EmailBody & "<br><b>Maxtel Sales Data:</b>"
    EmailBody = EmailBody & "<ul><br>Please note that because of the change to the Virtual SOE Maxtel is required to manually log on and install OnTarget."
    EmailBody = EmailBody & "<br><br>Sales data will start flowing through to Maxtel Web after a few hours."
    EmailBody = EmailBody & "<br><br>If it reaches midday and you are still having issues with sales data to either Maxtel Web or OnTarget please reach out to Certeq via the Hyper-Support Chat.</ul>"
    
    EmailBody = EmailBody & "<br>If you have any urgent issues that are impacting trade please contact our After Hours Support via:"

    EmailBody = EmailBody & "<br><br><ul>Certeq Project Team"
    EmailBody = EmailBody & "<br><a href=""mailto:mcd@certeq.co.nz"">mcd@certeq.co.nz</a>"
    EmailBody = EmailBody & "<br>Phone: <a href=""tel:+61448003441"">+61 448 003 441</a></ul>"

    EmailBody = EmailBody & "<br>If you would like to provide us with some feedback on this installation, this can be completed via: <a href=""https://feedback.certeq.com.au"">feedback.certeq.com.au</a>"

    EmailBody = EmailBody & "<br>"
    EmailBody = EmailBody & SignatureContent

    With OutMail
        .To = email_dl
        .CC = email_cc
        .BCC = ""
        .Subject = "[Post Deployment Support] Ref ID: " & Ref_ID & " | KVS1 Conversion: " & Site_ID & " - " & Site_Name
        .HTMLBody = EmailBody
        .Display
    End With
End Sub



