VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} API_Login 
   Caption         =   "Certeq Console"
   ClientHeight    =   5310
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   8925.001
   OleObjectBlob   =   "API_Login.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "API_Login"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub TB2_KeyPress(ByVal KeyAscii As MSForms.ReturnInteger)
    If KeyAscii = 27 Then Unload Me
End Sub
Private Sub UserForm_Initialize()
 TB1.value = GetSetting("Certeq", "Portal_API", "UserName")
 UserNameID = GetSetting("Certeq", "Portal_API", "UserNameID")
    If UserNameID > 0 Then
         TB2.value = "********************"
    Else
        TB2.value = ""
    End If
    If Format(GetSetting("Certeq", "Portal_API", "TokenExpiry"), "00000.00000") > Format(Now(), "00000.00000") Then
    API_Status.Caption = "Active"
    API_Status.ForeColor = &H80000007
    Else:
    API_Status.Caption = "Inactive"
    API_Status.ForeColor = &HFF
    End If
End Sub
Private Sub CommandButton1_Click()
    Unload Me
    'Set Array Variables
    Dim objRequest As Object
    Dim jsonStr, json, user, pwd As String

    Dim result As String

    json = "{""username"": " & Chr(34) & TB1.value & Chr(34) & ",""password"": " & Chr(34) & GetSetting("Certeq", "Portal_API", "UserNameID") & Chr(34) & ",""grant_type"": ""password""}"
    SaveSetting "Certeq", "Portal_API", "UserName", TB1.value
    If TB2.value = "********************" Then
        Else
        SaveSetting "Certeq", "Portal_API", "UserNameID", TB2.value
        End If
    'Debug.Print json
    Set objRequest = CreateObject("MSXML2.ServerXMLHTTP")
    URL = "https://api.certeq.com.au/oauth/token"
    Debug.Print json
    'Call API
    With objRequest
        .Open "POST", URL, False
        .setRequestHeader "Content-type", "application/json"
        .Send (json)
        jsonStr = .ResponseText
    End With
    Debug.Print jsonStr
    'Set Array Variables
    Dim x, y, row, col As Integer
    'Determin Array Size
    y = 500
    x = 2
    'JSON
    Dim PosChr, StrSub As String
    Dim LenStr, PosStr, StrText, ValTxt, StrSubR, StartLabel, Endlabel, StartValue, EndValue, ArrayX, ArrayY As Integer
     PosStr = 1
    StrText = 0
    ValTxt = 0
    LenStr = Len(jsonStr)
    ReDim ExportArray(y, x)
    Do Until PosStr = LenStr + 1
        PosChr = Mid(jsonStr, PosStr, 1)
        If PosChr = Chr(34) Then
            If StrText = 0 Then
                StartLabel = PosStr + 1
                StartValue = PosStr + 1
                StrText = 1
                ValTxt = 1
            Else
                StrText = 0
            End If
        End If
        If StrText = 0 Then
            Select Case PosChr
                Case "{":
                Case ":":   Endlabel = PosStr - 1
                           'Debug.Print Mid(JsonStr, StartLabel, Endlabel - StartLabel)
                            ExportArray(ArrayY, 0) = Mid(jsonStr, StartLabel, Endlabel - StartLabel)
                            ValTxt = 0
                            StartValue = PosStr + 1
                Case ",":
                            If ValTxt = 1 Then
                                EndValue = PosStr - 1
                                ValTxt = 0
                            Else:
                                EndValue = PosStr
                            End If
                            'Debug.Print "  " & Mid(JsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                            ArrayY = ArrayY + 1
                            StartValue = PosStr
                Case "}":   EndValue = PosStr - 1
                            'Debug.Print "  " & Mid(JsonStr, StartValue, EndValue - StartValue)
                            ExportArray(ArrayY, 1) = Mid(jsonStr, StartValue, EndValue - StartValue)
                                ArrayY = ArrayY + 1
                            StartValue = PosStr + 1
            Case Else:      End Select
        Else
            Select Case PosChr
                Case "\": Do Until Mid(jsonStr, PosStr, 1) = " "
                            PosStr = PosStr + 1
                        Loop
                Case Else:      End Select
        End If
        PosStr = PosStr + 1
    Loop
    
    'Deploy Arrary
    For rw = 0 To ArrayY
       For col = 0 To x
            'Sheet2.Range("A1").Offset(rw, col).Value = ExportArray(rw, col)
            If ExportArray(rw, col) = "display_name" Then
            col = col + 1
            SaveSetting "Certeq", "Portal_API", "UserDisplay", ExportArray(rw, col)
            Else: End If
            If ExportArray(rw, col) = "user_id" Then
            col = col + 1
            SaveSetting "Certeq", "Portal_API", "UserID", ExportArray(rw, col)
            Else: End If
            If ExportArray(rw, col) = "access_token" Then
            col = col + 1
            SaveSetting "Certeq", "Portal_API", "Token", ExportArray(rw, col)
            Else: End If
            If ExportArray(rw, col) = "expires_in" Then
            col = col + 1
            SaveSetting "Certeq", "Portal_API", "TokenExpiry", DateAdd("s", ExportArray(rw, col), Now())
            Else: End If
       Next col
    Next rw
    
End Sub
