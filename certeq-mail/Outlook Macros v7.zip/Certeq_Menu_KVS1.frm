VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} Certeq_Menu_KVS1 
   Caption         =   "Certeq Console"
   ClientHeight    =   5415
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   9060.001
   OleObjectBlob   =   "Certeq_Menu_KVS1.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "Certeq_Menu_KVS1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub CommandButton2_Click()
Unload Me
Call SOE_NZ_Recovery
End Sub

Private Sub CommandButton3_Click()
Unload Me
Call Maxtel_Recovery
End Sub

Private Sub CommandButton4_Click()
Unload Me
Call KVS_NZ_Completion_Issues
End Sub

Private Sub CommandButton5_Click()
Unload Me
KVS_NZ_Completion_Issues_Update
End Sub

Private Sub Completion_Click()
Unload Me
Call KVS1_NZ_Completion
End Sub

Private Sub DMAAS_Click()
Unload Me
Call DMAAS_NZ
End Sub
